public class Categoria {

    private String slug;
    private String name;
    private Categoria pai;

    public String getSlug() {
        return slug;
    }
    public void setSlug(String slug) {
        this.slug = slug;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Categoria getPai() {
        return pai;
    }
    public void setPai(Categoria pai) {
        this.pai = pai;
    }

    

    public Categoria() {
        this.slug = "";
        this.name = "";
        this.pai = null;
    }
    public Categoria(String slug, String name, Categoria pai) {
        this.slug = slug;
        this.name = name;
        this.pai = pai;
    }

    @Override
    public String toString() {
        return "Categoria [slug=" + slug + ", nome=" + name + ", pai=" + pai + "]";
    }

    

    

}

    
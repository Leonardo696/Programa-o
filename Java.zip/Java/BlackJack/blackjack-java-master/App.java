public class App {
    public static void main(String[] args) throws Exception {
        BlackJack blackJack = new BlackJack();
    }
}

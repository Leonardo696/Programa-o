import java.util.Calendar;

public class Aluno {
    //Atributos
    private String codigo;
    private String nomeProprio; 
    private String nomeApelido;
    private int anoNascimento;
    private String turma;

    //Getters & Setters
    public String getCodigo() {
        return codigo;
    }
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    public String getNomeProprio() {
        return nomeProprio;
    }
    public void setNomeProprio(String nomeProprio) {
        this.nomeProprio = nomeProprio;
    }
    public String getNomeApelido() {
        return nomeApelido;
    }
    public void setNomeApelido(String nomeApelido) {
        this.nomeApelido = nomeApelido;
    }
    public int getAnoNascimento() {
        return anoNascimento;
    }
    public void setAnoNascimento(int anoNascimento) {
        this.anoNascimento = anoNascimento;
    }
    public String getTurma() {
        return turma;
    }
    public void setTurma(String turma) {
        this.turma = turma;
    }

    //toString 
    @Override
    public String toString() {
        return "Aluno [codigo=" + codigo + ", nomeProprio=" + nomeProprio + ", nomeApelido=" + nomeApelido
                + ", anoNascimento=" + anoNascimento + ", turma=" + turma + "]";
    }

    //Construtor vazio que toma o valor nulo consoante o seu tipo de dados
    public Aluno() {
        this.codigo = "";
        this.nomeProprio = "";
        this.nomeApelido = "";
        this.anoNascimento = 0;
        this.turma = "";
    }

    //Construtor que recebe os argumentos para colocar em todos os atributos.
    public Aluno(String codigo, String nomeProprio, String nomeApelido, int anoNascimento, String turma) {
        this.codigo = codigo;
        this.nomeProprio = nomeProprio;
        this.nomeApelido = nomeApelido;
        this.anoNascimento = anoNascimento;
        this.turma = turma;
    }

    //Metodo que devolve o nome completo 
    public String getNomeCompleto() {
        String aux3 = "";

        aux3 += "Codigo: " + this.codigo;
        aux3 += "\n";
        aux3 += "Nome: " + this.nomeProprio;
        aux3 += "\n";
        aux3 += "Apelido: " + this.nomeApelido;
        aux3 += "\n";
        aux3 += "Turma: " + this.turma;
        aux3 += "\n";

        return aux3;
    }

    //Devolve a idade, usa-se o int currentYear = Calendar.getInstance().get(Calendar.YEAR) menos o ano de nascimento e da a idade do aluno
    public int getIdade() {
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        return currentYear - anoNascimento;
    }
}

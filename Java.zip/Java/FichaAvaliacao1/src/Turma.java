class Turma {
    //Atributos
    private String codigo;
    private String nomeCurso;
    private int anoInicio;
    private int anoFim;

    //Getters & Setters
    public String getCodigo() {
        return codigo;
    }
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    public String getNomeCurso() {
        return nomeCurso;
    }
    public void setNomeCurso(String nomeCurso) {
        this.nomeCurso = nomeCurso;
    }
    public int getAnoInicio() {
        return anoInicio;
    }
    public void setAnoInicio(int anoInicio) {
        this.anoInicio = anoInicio;
    }
    public int getAnoFim() {
        return anoFim;
    }
    public void setAnoFim(int anoFim) {
        this.anoFim = anoFim;
    }

    //toString
    @Override
    public String toString() {
        return "Turma [codigo=" + codigo + ", nomeCurso=" + nomeCurso + ", anoInicio=" + anoInicio + ", anoFim="
                + anoFim + "]";
    }

    //Construtor vazio que toma o valor nulo consoante o seu tipo de dados
    public Turma() {
        this.codigo = "";
        this.nomeCurso = "";
        this.anoInicio = 0;
        this.anoFim = 0;
    }

    //Construtor que recebe os argumentos para colocar em todos os atributos.
    public Turma(String codigo, String nomeCurso, int anoInicio, int anoFim) {
        this.codigo = codigo;
        this.nomeCurso = nomeCurso;
        this.anoInicio = anoInicio;
        this.anoFim = anoFim;
    }

    //Metodo que devolve a Informação tratada e visivelmente bem formada separada por Linhas e com a identificação em Letras Normais, e o que está na Informação dos atributos, em CAPS LOCK
    public String getInfoTurma() {
        String aux2 = "";

        aux2 += "Codigo: " + this.codigo.toUpperCase();
        aux2 += "\n";
        aux2 += "Curso: " + this.nomeCurso.toUpperCase();
        aux2 += "\n";
        aux2 += "Ano inicial: " + this.anoInicio;
        aux2 += "\n";
        aux2 += "Ano final: " + this.anoFim;
        aux2 += "\n";

        return aux2;
    }
}

public class App {
    public static void main(String[] args) throws Exception {
        //Criacao de objetos e chamamento de todos os metodos
        Professor professor1 = new Professor(55543, "Luis", "Santos", 1986, "Programacao");
        System.out.println(professor1);
        System.out.print(professor1.getNomeCompleto());
        Turma turma1 = new Turma("cs654", "Programacao", 2023, 2026);
        System.out.println(turma1);
        System.out.println(turma1.getInfoTurma());
        Aluno alunos1 = new Aluno("a14521", "Leonardo", "Machado", 2008, "1ºP");
        System.out.println(alunos1);
        System.out.println(alunos1.getNomeCompleto() + "Idade: " + alunos1.getIdade());

        
    }
}

public class Main {
    public static void main(String[] args) {
        
        DispositivoMovel dp = new DispositivoMovel();
        System.out.println("Tipo do Dispositivo #1 : " + dp.getTipo());
        
        Telemovel tlm1 = new Telemovel();
        System.out.println("Tipo do tlm1 #1 : " + tlm1.getTipo());
        tlm1.setSerialNumber("gjgsaf-34-dff");
        System.out.println("Serial do tlm1 #1 : " + tlm1.getSerialNumber());

        Tablet tablet1 = new Tablet();
        System.out.println("Tipo do Tablet #1 : " + tablet1.getTipo());
        tablet1.setSerialNumber("gvsdf-45-fstydf");
        System.out.println("Serial do tablet1 #1 : " + tablet1.getSerialNumber());

        Portatil portatil1 = new Portatil();
        System.out.println("Tipo do Portatil #1 : " + portatil1.getTipo());
        portatil1.setSerialNumber("jkgfbhfd-64-bfvsd");
        System.out.println("Serial do portatil #1 : " + portatil1.getSerialNumber());

    }
}

class DispositivoMovel {
    
    String tipo = "";
    String serialNumber = "";

    public String getTipo() {
        return this.tipo;
    }
}

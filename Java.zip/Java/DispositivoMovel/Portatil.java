class Portatil extends DispositivoMovel{
    public Portatil() {
        this.tipo = "Portatil";
    }

    public String getSerialNumber() {
        return this.serialNumber;
    }

    public void setSerialNumber(String txt) {
        this.serialNumber = txt;
    }
}

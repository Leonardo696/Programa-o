class Tablet extends DispositivoMovel {
    public Tablet() {
        this.tipo = "Tablet";
    }

    public String getSerialNumber() {
        return this.serialNumber;
    }

    public void setSerialNumber(String txt) {
        this.serialNumber = txt;
    }
}

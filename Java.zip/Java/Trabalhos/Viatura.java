public class Viatura {
    protected String brand = "Ford";
    
    public void buzinar() {
        System.out.println("Tuut, tuut!");
    }
}
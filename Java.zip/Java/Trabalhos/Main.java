public class Main {
    public static void main(String[] args) {

        if (args.length > 0) {
            System.out.println("Recebi os seguintes argumentos: ");
            for (String i: args) {
                System.out.println(i);
            }
        }

        alunos alunos1 = new alunos(14521, "Leonardo Machado", 962235198, "4795-145");
        alunos1.mostraInfo();

        System.out.println("NOVO***********************************");
        carro myCarro1 = new carro("Opel", "Astra 1.6 GTI", "01-OP-82", 2014, 76852);

        myCarro1.mostraInfo();
        myCarro1.buzinar();

    }
}

class Viatura {
    protected String brand = "Ford";
    
    public void buzinar() {
        System.out.println("Tuut, tuut!");
    }
}

public class carro extends Viatura {

    private String marca;
    private String modelo;
    private String matricula;
    private int ano;
    private int kms;

    public void setmarca(String marca) {
        this.marca = marca;
    }
    
    public String getmarca() {
        return marca; 
    }

    public void setmodelo(String modelo) {
        this.modelo = modelo;
    }

    public String getmodelo() {
        return modelo; 
    }

    public void setmatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getmatricula() {
        return matricula; 
    }

    public void setano(int ano) {
        this.ano = ano;
    }

    public int getano() {
        return ano; 
    }

    public void setkms(int kms) {
        this.kms = kms;
    }

    public int getkms() {
        return kms; 
    }

    public void mostraInfo() { 
        System.out.println("Marca: " + this.getmarca());
        System.out.println("Modelo: " + this.getmodelo());
        System.out.println("Matricula: " + this.getmatricula());
        System.out.println("Ano: " + this.getano());
        System.out.println("Kms: " + this.getkms());
    }

    public carro(String marcaX, String modeloX, String matriculaX, int anoX, int kmsX) {
        this.marca = marcaX;
        this.modelo = modeloX;
        this.matricula = matriculaX;
        this.ano =anoX;
        this.kms = kmsX;
    }
    
    public void buzinar() {
        System.out.println("Beep, Beep!");
    }
}

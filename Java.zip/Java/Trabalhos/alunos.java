public class alunos {
    int numAluno;
    String nomeAluno; 
    private int tlfAluno;
    private String moradaAluno;
    
    public void setnumAluno(int numAluno) {
        this.numAluno = numAluno;
    }

    public int getnumAluno() {
        return numAluno;
    }

    public void setnomeAluno(String nomeAluno) {
        this.nomeAluno = nomeAluno;
    }

    public String getnomeAluno() {
        return nomeAluno;
    }

    public void settlfAluno(int tlfAluno) {
        this.tlfAluno = tlfAluno;
    }

    public int gettlfAluno() {
        return tlfAluno;
    }

    public void setmoradaAluno(String moradaAluno) {
        this.moradaAluno = moradaAluno;
    }

    public String getmoradaAluno() {
        return moradaAluno;
    }

    public alunos(int numAlunoX, String nomeAlunoX, int tlfAlunoX, String moradaAlunoX) {
        this.numAluno = numAlunoX;
        this.nomeAluno = nomeAlunoX;
        this.tlfAluno = tlfAlunoX;
        this.moradaAluno = moradaAlunoX;
    }

    public void mostraInfo() {
        System.out.println("Numero: " + this.getnumAluno());
        System.out.println("Nome: " + this.getnomeAluno());
        System.out.println("Telefone: " + this.gettlfAluno());
        System.out.println("Morada: " + this.getmoradaAluno());
    }

}

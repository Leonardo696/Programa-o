// javac MainTeste.java
// java -cp . MainTeste
public class MainTeste {

    static int calculaNumerosBiDimensionais() {
        /*String name = "Leonardo";\
        name = name.concat(" Machado");
        int pos = name.indexOf("Machado");
        if (pos >= 0) {
            System.out.println("Encontrei na pos: " + pos);
        } else {
            System.out.println("Nao Encontrei");
        }*/
        /*String[] alunos = {"Leonardo", "Rodrigo", "Vasco"};
        for (String dados : alunos) {
            System.out.println(dados);
        }*/
        int[][] myNumbers = { {1, 2, 3, 4, 5}, {6, 7} };
        int somaTotal = 0;
        /*for (int numero : myNumbers[0]) {
            myNumbers1 += numero;
        }
        for (int numero : myNumbers[1]) {
            myNumbers2 += numero;
        }
        System.out.println(myNumbers1);
        System.out.println(myNumbers2);
        System.out.println(myNumbers1 + myNumbers2);*/
        for (int[] arrayNum : myNumbers) {
            for (int numero : arrayNum) {
                somaTotal += numero;
            }
        }
        return somaTotal;
    }
    public static int fatorial(int k) {
        if ( k > 1) {
            return (k * fatorial(k - 1));
        } else {
            return k;
        }
    }
    static void mostraSoma(int numero) {
        System.out.println("O Resultado e: " + numero);
    }
    static void mostraSoma(double numero) {
        System.out.println("O Resultado e: " + numero);
    }

     public static void main (String[] args) {
        System.out.println(calculaNumerosBiDimensionais());
    }
}
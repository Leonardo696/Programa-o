// javac Main.java
// java -cp . Main
public class Oop1 {

    private int x = 5;
    int y = 10;

    static void metodoEstatico() {
        System.out.println("Metodo Estatico");
    }

    static void metodoPublico() {
        System.out.println("Metodo Publico");
    }

    public void setX(int num) {
        this.x = num;
    }

    public int getX() {
        return this.x;
    }

    public Oop1() {
        this.x = 33;
    }

    public static void main(String[] args) {
        Oop1 myObj1 = new Oop1();
        Oop1 myObj2 = new Oop1();
        
        System.out.println(myObj1.getX());
        myObj1.setX(13);
        System.out.println(myObj1.getX());
        //System.out.println(myObj1.x);
        myObj1.y = 15;
        myObj2.y = 35;

        System.out.println(myObj1.y + myObj2.y);

        metodoEstatico();
        metodoPublico();
    }
}
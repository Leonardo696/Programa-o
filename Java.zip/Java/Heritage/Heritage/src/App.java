import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class App {
    public static void main(String[] args) throws Exception {
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        String dataStr = "1976/04/05";
        String dataStr2 = "1974/07/15";
        String dataStr3 = "1968/06/28";
        String dataStr4 = "1966/11/17";
        String dataStr5 = "1988/04/11";
        String dataStr6 = "1986/09/26";
        String dataStr7 = "2008/10/08";

        Pessoa avo1 = new Pessoa("Maria", "Filomena", LocalDate.parse(dataStr, formato), null, null, false, null);
        Pessoa avo2 = new Pessoa("Abilio", "Martinho", LocalDate.parse(dataStr2, formato), null, null, true, LocalDate.parse("2022/01/01", formato));
        Pessoa avo3 = new Pessoa("Antonio", "Salgado", LocalDate.parse(dataStr3, formato), null, null, false, null);
        Pessoa avo4 = new Pessoa("Maria", "Jose", LocalDate.parse(dataStr4, formato), null, null, false, null);

        Pessoa pai = new Pessoa("Nelson", "Machado", LocalDate.parse(dataStr5, formato), avo2, avo1, false, null);
        Pessoa mae = new Pessoa("Rita", "Martins", LocalDate.parse(dataStr6, formato), avo3, avo4, false, null);

        Pessoa eu = new Pessoa("Leonardo", "Machado", LocalDate.parse(dataStr7, formato), pai, mae, false, null);

        System.out.println(eu.mostraDescendencia(0));
    }
}

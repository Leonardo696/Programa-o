public class App {
    public static void main(String[] args) throws Exception {
        Carro carro1 = new Carro(true, 0);
        Carro carro2 = new Carro(false, 7);
        Carro carro3 = new Carro();
        Carro carro4 = new Carro();

        Mota mota1 = new Mota(true, "Suporte de Mala Traseira");
        Mota mota2 = new Mota();
        
        System.out.println(carro1);
    }
}

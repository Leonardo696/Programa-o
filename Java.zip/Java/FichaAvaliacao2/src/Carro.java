public class Carro extends Veiculo {
    private boolean classico; //Atributos
    private int numeroLugares;

    public boolean isClassico() { //Getters & Setters
        return classico;
    }
    public void setClassico(boolean classico) {
        this.classico = classico;
    }
    public int getNumeroLugares() {
        return numeroLugares;
    }
    public void setNumeroLugares(int numeroLugares) {
        this.numeroLugares = numeroLugares;
    }
    
    public Carro() {
        this.classico = false;
        this.numeroLugares = 0;
    }
    public Carro(boolean classico, int numeroLugares) {
        this.classico = classico;
        this.numeroLugares = numeroLugares;
    }

    @Override
    public String toString() { //toString
        return "Carro [classico=" + classico + ", numeroLugares=" + numeroLugares + "]";
    }
    public String getInfo() { //info para devolver
        String aux = "";

        aux += "Classico: " + this.isClassico();
        aux += "\n";
        aux += "Numero Lugares: " +this.getNumeroLugares();
        return aux;
    }
}

public class Mota extends Veiculo {
    private boolean pagaIUC;
    private String suporteMalas;

    public boolean ispagaIUC() {
        return pagaIUC;
    }
    public void setClassico(boolean pagaIUC) {
        this.pagaIUC = pagaIUC;
    }
    public String getsuporteMalas () {
        return suporteMalas;
    }
    public void setsuporteMalas (String suporteMalas) {
        this.suporteMalas = suporteMalas;
    }

    public Mota() {
        this.pagaIUC = false;
        this.suporteMalas = "";
    }
    public Mota(boolean classico, String suporteMalas) {
        this.pagaIUC = pagaIUC;
        this.suporteMalas = suporteMalas;
    }
    @Override
    public String toString() {
        return "Mota [pagaIUC=" + pagaIUC + ", suporteMalas=" + suporteMalas + "]";
    }

    public String getInfo() {
        String aux = "";

        aux += "Paga IUC: " + this.ispagaIUC();
        aux += "\n";
        aux += "suporteMalas: " +this.getsuporteMalas();
        return aux;
    }


}

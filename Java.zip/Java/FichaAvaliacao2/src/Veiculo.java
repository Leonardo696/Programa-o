import java.time.LocalDate;
import java.time.Period;

public class Veiculo {
    private String matricula;
    private LocalDate dataDaMatricula;
    private String marca;
    private int numeroRosas;
    private float iuc;
    private String tipoDeVeiculo;
    private String combustivel;
    private float kms;

    public String getMatricula() {
        return matricula;
    }
    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }
    public LocalDate getDataDaMatricula() {
        return dataDaMatricula;
    }
    public void setDataDaMatricula(LocalDate dataDaMatricula) {
        this.dataDaMatricula = dataDaMatricula;
    }
    public String getMarca() {
        return marca;
    }
    public void setMarca(String marca) {
        this.marca = marca;
    }
    public int getNumeroRosas() {
        return numeroRosas;
    }
    public void setNumeroRosas(int numeroRosas) {
        this.numeroRosas = numeroRosas;
    }
    public float getIuc() {
        return iuc;
    }
    public void setIuc(float iuc) {
        this.iuc = iuc;
    }
    public String getTipoDeVeiculo() {
        return tipoDeVeiculo;
    }
    public void setTipoDeVeiculo(String tipoDeVeiculo) {
        this.tipoDeVeiculo = tipoDeVeiculo;
    }
    public String getCombustivel() {
        return combustivel;
    }
    public void setCombustivel(String combustivel) {
        this.combustivel = combustivel;
    }
    public float getKms() {
        return kms;
    }
    public void setKms(float kms) {
        this.kms = kms;
    }

    public Veiculo() {
        this.matricula = "";
        this.dataDaMatricula = null;
        this.marca = "";
        this.numeroRosas = 0;
        this.iuc = 0;
        this.tipoDeVeiculo = "";
        this.combustivel = "";
        this.kms = 0;
    }
    public Veiculo(String matricula, LocalDate dataDaMatricula, String marca, int numeroRosas, float iuc, String tipoDeVeiculo, String combustivel, float kms) {
        this.matricula = matricula;
        this.dataDaMatricula = dataDaMatricula;
        this.marca = marca;
        this.numeroRosas = numeroRosas;
        this.iuc = iuc;
        this.tipoDeVeiculo = tipoDeVeiculo;
        this.combustivel = combustivel;
        this.kms = kms;
    }

    @Override
    public String toString() {
        return "Veiculo [matricula=" + matricula + ", dataDaMatricula=" + dataDaMatricula + ", marca=" + marca
                + ", numeroRosas=" + numeroRosas + ", iuc=" + iuc + ", tipoDeVeiculo=" + tipoDeVeiculo
                + ", combustivel=" + combustivel + ", kms=" + kms + "]";
    }

    public int getIdade() {
        LocalDate dataAtual = LocalDate.now();
        Period periodo = Period.between(dataDaMatricula, dataAtual);
        return periodo.getYears();
    }
}
class Dog extends Animal {
    public void animalSound() {
        System.out.println("O Cao faz: au auuuuuu");
    }
}
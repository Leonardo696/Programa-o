class Animal {

    String name = "Animal";
    
    public void animalSound() {
        System.out.println("O " + this.name + " faz sons...");
    }
}
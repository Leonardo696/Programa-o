public class Main {
    public static void main(String[] args) {
        Animal animal = new Animal();
        animal.animalSound();

        Pig porco = new Pig();
        porco.animalSound();

        Dog cao = new Dog();
        cao.animalSound();
    }
}

public class Pig {
    public void animalSound() {
        System.out.println("O porco faz: oink oink");
    }
}

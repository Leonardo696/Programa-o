public class App {
    public static void main(String[] args) throws Exception {

        Livraria livraria1 = new Livraria("Leonardo Machado", "S.Martinho Do Campo - Rua Fernado Pinheiro da Rocha", "Santo Tirso", 221234567, "");
        //System.out.println(livraria1);
        //System.out.println("Nome da Livraria: " + livraria1.getNome());
        System.out.println("Morada de Envio: " + "\n" + livraria1.getMoradaCompleta());

        Estante estante1 = new Estante("E1", "R/CHAO");
        //System.out.println(estante1);

        Leitor leitor1 = new Leitor(14521, "Leonardo Machado", "S.Martinho Do Campo - Rua Fernado Pinheiro da Rocha", 962235198, "a14521@oficina.pt", "Masculino");
        //System.out.println(leitor1);
        System.out.println("Leitor: " + leitor1.getTelefoneString() + leitor1.getIniciais());

        Livro livro1 = new Livro("Princepizinho", "Luis Santos", 456);
        //System.out.println(livro1);
        System.out.println("Informacao do Livro: " + "\n\n" + livro1.getInfoLivro());
    }
}

def somar2(v1,v2 = 3,v3 = None):
#     if v3 is None:
#         return v1 + v2
#     else: 
#         return v1 + v2 + v3
# s = somar2(8,5,4)
# print(s)

# def somar3(a, *args):
#     soma = 0
#     for arg in args:
#         soma = soma + arg
#     return soma

# print(somar3(1,2,3))
# print(somar3(1,2,3,4,5))
# print(somar3(1,2,3,4,5,6,7))

# # lista = [1,2,3,4,5]
# # a,b,*c = lista
# # print(a,b,c)

# def total_impares(*args):
#     contagem = 0
#     for arg in args:
#         if arg % 2 == 1: # É impar
#             contagem += 1
#     return contagem
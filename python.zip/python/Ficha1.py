# Q1

def somar(*elems):
    s = 0
    for elem in elems:
        if 5 < elem < 10:
            s = s + elem
    return s

print(somar(3,6,9,12))

# Q2

Positivo_negativo = lambda x: "P" if x >= 0 else "N"
print(Positivo_negativo(5))

# Q3

NUM = 123

def inverter(NUM):
    inverso = 0
    while NUM != 0:
        inverso = inverso *10 + NUM % 10
        NUM = NUM //10
    return inverso

print(inverter(321))

# Q4

contar_digitos = lambda num: len(str(num))
numero = int(input("Digite um valor: "))
print(contar_digitos(numero))

# Q5

def perfeito(num):
    soma = 0
    for divisor in range(1,num):
        if num % divisor == 0:
            soma = soma + divisor
    if num == soma:
        print("Perfeito")
    else:
        print("Imperfeito")

perfeito(10)


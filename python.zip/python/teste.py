#print("Hello, World!")
#print("Atenção")

x = 5
#if x > 7:
#    print("Conseguiu")
#    print("Teste")
#elif x < 3:
#    print("Chumbado")
#else:
#    print("Tentar novamente")

#print(type(x)) #O type serve para dizer que tipo de variavel é
x = "Leonardo"
n = 15
#print(x)  
#print(type(x))

#print("O meu nome é",x,"e a minha idade é",n)
#print("O meu nome é " + x + " e a minha idade é " + str(n))
#print(f'O meu nome é {x} e a minha idade é {n}')

produto1 = "Martelo"
produto2 = "Alicate"
produto3 = "Tesoura"

#print(produto1,end=', ')
#print(produto2,end=', ')
#print(produto3)

#import os # Importa todas as funções da biblioteca 
#from random import randrange # Importa a função randrange do módulo random

#num1 = randrange(1,10)
#print(num1)
#num2 = randrange(1,20)
#print(num2)
#num1 = int(input("Digite o primeiro valor: "))
#num2 = int(input("Digite o segundo valor: "))
#print("Soma =", num1+num2)

#frase = "Maioria dos alunos"
#print(frase[0:12]) # Primeiros 11 caracteres
#print(frase[12:])
#print(len(frase)) # Total de caracteres na frase

frase = "Maioria dos alunos"
frase2 = frase.replace("Maioria","Minoria")
print(frase2)

lista_de_palavras = frase.split(" ")
print(type(lista_de_palavras))
print(lista_de_palavras)

for palavra in lista_de_palavras:
    print(palavra)

for i in range(10):
    print(i)
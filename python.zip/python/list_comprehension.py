lista = []
lista_1 = [n for n in range(1,11)]
print(lista_1)

lista_2 = [n*2 for n in range(21)]
print(lista_2)

lista_3 = [
    num # Elementos da lista
    for num in range(21) # Elementos selecionados
    if num % 2 == 0 # Filtro dos elementos
]
print(lista_3)
aluno = {
    'nome': 'Marcelo',
    'nota_matematica': 12.5,
    'nota_portugues': 13.25,
    'outras_notas': [13,14.25,17.5,8.25] 
}

print(aluno['outras_notas'][1])

for k in aluno: # Imprime a chave
    print(k)
print('----------------------------------------)')
for v in aluno.values(): # Imprime os valores
    print(v)
print('----------------------------------------)')
for k,v in aluno.items():
    print(f'{k}: {v}')

alunos = [
    {
    'nome': 'Marcelo',
    'nota_matematica': 12.5,
    'nota_portugues': 13.25,
    'outras_notas': [13,14.25,17.5,8.25] 
    },
    {
    'nome': 'Ana',
    'nota_matematica': 17.5,
    'nota_portugues': 8.25,
    'outras_notas': [12,11.25,17.5,8.25] 
    }
]

print(alunos[1]['nome'])

nomes = ['marcelo','ana','joao']
print(nomes[0][2])

nome = 'Marcelo'
nome = ['M','a','r','c','e','l','o']

def somar(**nums):
    soma = 0
    for num in nums.values():
        soma = soma + num
    return soma

def somar2(**nums):
    soma = 0
    for num in nums.values():
        soma = soma + num
    return soma

x = somar(num1 = 5,num2 = 2)
y = somar2(4,5)

# p = 3
# def somar(y = 4):
#     x = 2
#     s = x + y
#     print(s)
# print(somar())
# somar(p)
# somar()

def somar2(v1,v2 = 3,v3 = None):
    if v3 is None:
        return v1 + v2
    else: 
        return v1 + v2 + v3
s = somar2(8,5,4)
print(s)

def somar3(a, *args):
    soma = 0
    for arg in args:
        soma = soma + arg
    return soma

print(somar3(1,2,3))
print(somar3(1,2,3,4,5))
print(somar3(1,2,3,4,5,6,7))

# lista = [1,2,3,4,5]
# a,b,*c = lista
# print(a,b,c)

def total_impares(*args):
    contagem = 0
    for arg in args:
        if arg % 2 == 1: # É impar
            contagem += 1
    return contagem

# Funções anónimas 

soma = lambda x,y: x + y
print(soma(3,2))
par = lambda x: "Par" if x % 2 == 0 else "Ímpar"
print(par(5))

lista = [2,3,4] 
dobro = map(lambda x: x * 2, lista)
print(list(dobro)) 
metade_inteira = map(lambda x: x//2, lista)
print(list(metade_inteira))
quadrado = map(lambda x: x ** 2, lista)
print(tuple(quadrado)) 